# php-obfuscator
A set of tools design to obfuscate php

Used by :

wp-obfuscator
