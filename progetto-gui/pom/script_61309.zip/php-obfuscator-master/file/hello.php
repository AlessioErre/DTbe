<?php 
/*
Author: Adrien Thierry
Licence: GPLv2 or later
http://seraum.com
http://asylum.seraum.com
http://hackmyfortress.com
*/

/* A SIMPLE HELLO WORLD FILE */

echo "HELLO WORLD";

?>
